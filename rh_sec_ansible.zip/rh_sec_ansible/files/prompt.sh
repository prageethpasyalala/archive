
if [ -f /etc/friendlyname ]
then
        PS1="`whoami`@`cat /etc/friendlyname`|`uname -n`$ "
else
        PS1="`whoami`@`uname -n`$ "
fi

